const base = {
    get() {
        return {
            url : "http://localhost:8080/django6o293/",
            name: "django6o293",
            // 退出到首页链接
            indexUrl: 'http://localhost:8080/django6o293/front/index.html'
        };
    },
    getProjectName(){
        return {
            projectName: "停车场信息管理系统"
        } 
    }
}
export default base
